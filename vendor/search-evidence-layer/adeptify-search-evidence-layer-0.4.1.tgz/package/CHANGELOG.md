# Changelog

## 0.4.1 - 2026-08-14

- Export a production `createSearchStorageFoundation` from `/host/node`: options are only `appId`, `keyNamespace`, `aead`, `secretStore`, a deadline-aware `operationStore`, and `contentStore`.
- The production handle is branded and public-only: `dataKeyStatus()` and `shutdown()`. Key generation uses `crypto.getRandomValues`; the trusted clock comes from the operation store.
- `createSearchIntentPersistenceV1` accepts a real production or testing handle and rejects a forged object-shaped handle.
- `/testing` keeps `createSearchStorageFoundationForTesting` with injected clock and key helpers.
- RSS/Atom/JSON Feed items enter materials only when they have a stable identity (the original id or an independent `http`/`https` URL) and an independent `http`/`https` URL. Bad items are skipped. At least one bad item stably returns the `ingest_incomplete` warning. Feed URL, `#item`/`#entry`, and non-URL ids cannot forge identity or URL. A missing title may still use `Untitled`.
- 本条目描述 0.4.1 release source snapshot；公开可用性以对应 tag/Release 页面为准。本快照不包含 npm publication、tag/Release 已经完成的声明，或 Relay 产品迁移。

## 0.4.0 - 2026-08-14

- Add an additive `@adeptify/search-evidence-layer/intent` surface for exact query/feed intents without changing the published V0 SearchPlan runtime.
- Enforce required/preferred/allowed/forbidden source policy through a deterministic exact compiler; exact mode never invokes a Planner or model.
- Add multi-dimensional task budget accounting, explicit reserves, trusted money pricing, and a zero-spend proof for pre-route terminal work.
- Add an encrypted, tenant-scoped Run Ledger with intent fingerprint idempotency, terminal replay, dispatch fencing, deadline-aware terminal commits, and reconciliation after ambiguous crashes.
- Verify a Relay-shaped RSS fixture through the existing RSS Provider and Host transport: construction is zero-network, replay is zero-new-network, changed intent conflicts before dispatch, and persisted content remains readable after restart.
- 本条目描述 0.4.0 release source snapshot；公开可用性以对应 tag/Release 页面为准。本快照不包含 npm publication、Relay product migration、Strategy Registry、Evidence Map 或 Adaptive Planner。

## 0.3.2 - 2026-08-13

- Accept the current AnySearch MCP Markdown response representation for search and extract while retaining backward-compatible JSON decoding.
- Keep AnySearch protocol drift handling inside the SDK Provider boundary; consumers continue to receive typed candidates, materials and receipts.
- Preserve namespaced `media:description` text when ingesting YouTube-compatible Atom feeds so public channel updates retain their bounded description instead of falling back to the title.

## 0.3.0 - 2026-08-09 development package

- Adopted the MIT license and added package-level provenance, CycloneDX SBOM and Node 24 release gates.
- Added deterministic release packaging with adjacent SHA-256 and machine-readable provenance.
- Declared stable package exports and public package metadata for exact-tarball consumers such as Relay.
- Added a public App-port-backed Node Host for controlled transport, SecretStore resolution and encrypted content persistence without HTTP/MCP indirection.
- Added path-scoped CI for typecheck, lint, unit/integration tests, SBOM drift and clean-tree packaging.

## 0.2.0 - 2026-08-07

- Phase 0: extended public contracts (`ingest` mode/operation, optional lane `query`/`feedUrl`, capability bits `feeds`/`streams`/`browser`/`auth`, feed/entity/subscription types); layered package exports.
- Phase 1: zero-dep RSS/Atom/JSON Feed parser, media source registry (11 sources), `rss`/`media` providers, runtime ingest path with `feed-v1` ranking and material mapping.
- Phase 2: capability registry, ordered backend failover, doctor channels rss/web/media/search.
- Phase 3: mock browser host (session save/restore, rate limit, shutdown); bilibili/weibo providers with creator anonymization.
- Phase 4: xhs/douyin/kuaishou/tieba/zhihu/twitter/reddit mock-first providers + pre-implementation review notes.
- Phase 5: subscription manager (register/revoke/quota/audit); `extractWithSubscription` returns `SubscriptionExtractOutcome` with `quota_hit` → warning `subscription_quota_hit` (summary kept, body skipped); media provider paywalled `extract` wired to SubscriptionManager.
- Phase 1 cursor: `FeedCursorStore` advance/failure/offline wired through rss/media providers.
- Phase 6: consumer daemon/CLI/local HTTP API/MCP/plugin adapters + `skills/search-evidence/SKILL.md`.
- Core remains free of Client-Core/Tauri/Alchemist/SQLite runtime deps; feed parser has no external XML dependency.

## 0.1.0

- Added the S0–S4 package contracts and AnySearch provider adapter.
- Added T5A Host-owned AnySearch V0 transport-profile fingerprints, authoritative deadline/cancel signals, and safe logger conformance fixtures; no production network factory is included yet.
- Added T5B internal pinned HTTPS/DNS transport rules; exact descriptor snapshots for resolver results, Provider execution requests and search/extract outputs; bounded warning/candidate/content validation with one tracker-derived failure receipt; synchronous post-await abort gates and raw-fence dispatch ordering; method-scoped execution closure and package-owned rejection observation; retryable `ENOTFOUND`/`EPROTO` normalization; Node-valid credential headers; re-entry-safe Runtime/Host shutdown barriers; physical `ClientRequest` close tracking; strict Node parser/header-byte normalization; and `/testing` scripted network conformance. No durable receipt or public production Host factory is included.
