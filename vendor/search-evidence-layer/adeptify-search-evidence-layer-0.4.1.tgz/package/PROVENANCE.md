# Package provenance

`@adeptify/search-evidence-layer` is released from the
`search-evidence-layer/` directory of
[`adeptify/trick-catalog`](https://github.com/adeptify/trick-catalog).

## Trust boundary

- Consumers install an exact versioned `.tgz`, never an unpinned source-tree dependency.
- The consumer records the source repository, source path, Git commit, package SHA-256 and npm-style SHA-512 integrity.
- `pnpm release:pack` writes a machine-readable provenance manifest next to the archive.
- A public release must be built from a clean Git tree with Node 24 and pnpm 11.9.0. Use `pnpm release:pack -- --require-clean`.
- npm publication must use trusted publishing/provenance; publishing is a separate maintainer-authorized action.
- `sbom.cdx.json`, `LICENSE`, this file and `third-party/NOTICE.md` are included in the package.

## Reproducible verification

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm release:pack -- --require-clean
shasum -a 256 release/adeptify-search-evidence-layer-*.tgz
```

The generated JSON manifest is the authority for a concrete archive. This
document describes the process and deliberately does not contain a mutable
“latest” hash.

## 0.4.1 release boundary

`0.4.1` 的公开可用性以对应 tag 与 GitHub Release 页面为准。正式资产必须来自 annotated tag 所指向的 clean source commit：exact tgz、相邻 SHA-256、machine-readable provenance 和 CycloneDX SBOM。发布门禁要求整个 trick-catalog 工作树 clean、Node 24、pnpm 11.9.0，并使用 `pnpm release:pack -- --require-clean`；provenance 必须报告该 source commit 且 `source.dirty=false`；Release 资产还须回下载复核。本文件只描述这些门禁，不声称 tag、Release 或回下载已经发生。已发布的 `0.3.2` 与已定稿的 `0.4.0` provenance 仍是历史事实，不被本快照覆盖。

## 0.4.0 release boundary

`0.4.0` 的公开可用性以对应 tag 与 GitHub Release 页面为准。正式资产必须来自 annotated tag 所指向的 clean source commit：exact tgz、相邻 SHA-256、machine-readable provenance 和 CycloneDX SBOM。本文件不声称 `0.4.0` tag、Release 或回下载已经发生。
