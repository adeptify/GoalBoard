# Third-Party Reuse Ledger

> 状态：M2 候选清单与台账模板
>
> 重要：下面项目目前都只是 `reviewed` / `inspired` 候选，**没有代码已复制进 SEL**。实施时必须重新从官方仓库取得 exact commit，并按实际复用方式更新状态、行号、目标文件、测试和 NOTICE。
>
> 阅读入口：先看大白话主文档 [`SEL 专业意图到证据引擎总体设计 V1`](../docs/superpowers/specs/2026-08-13-sel-intent-to-evidence-engine-v1.md)；本文只负责第三方研究与许可证台账。

## 1. 台账字段

每次直接复制或实质改编都新增一行，不能覆盖历史：

| 字段 | 含义 |
|---|---|
| upstream | 官方仓库名与 URL |
| exact commit | 实施时实际取得的 commit |
| source file / lines | 具体来源文件和必要行范围 |
| license | SPDX 标识；是否有 NOTICE / THIRD_PARTY_NOTICES |
| reuse type | `copied` / `adapted` / `inspired` |
| local target | 本地目标文件 |
| modifications | 与上游相比做了什么 |
| tests | 覆盖该复用点的测试 |
| date | 复用日期 |
| notice obligations | 需保留的版权、许可证、NOTICE 与修改说明 |
| reviewer | 审阅人或 agent |

## 2. 已审阅候选

### 2.1 AutoRAG 2.0

- 官方仓库：https://github.com/Marker-Inc-Korea/AutoRAG
- 审阅 commit：`f9e2b715b621f100400ef816526af2700a7e1593`
- 许可证：MIT。
- 重点文件：`src/memory/memory.ts`、`src/filesystem/file-lock.ts`、`src/retrieval/evidence-id.ts`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选复用：FeedbackOutcome / FeedbackSignalSource；explicit/followup/retry 分权重；implicit cap；`eventId + target` 幂等；feedback 按 evidence chunk 分配；带 score/confidence/reason 的 advisory MethodHint；多次支持且含 explicit 才形成 insight。
- 可能近直接复用：TypeScript + MIT 的反馈记账结构。若 SEL durable 不足，可考虑 lock + temp + atomic rename；必须先证明现有 durable 不能满足。
- 不采用：query substring 匹配、简单 token cluster、固定阈值直接当产品标准。

### 2.2 SearchClaw

- 官方仓库：https://github.com/RUC-NLPIR/SearchClaw
- 审阅 commit：`818c43fdfd20368074ba020ea133e3844b500314`
- 许可证：MIT。
- 重点文件：`src/hooks/engine.py`、`src/hooks/builtin_hooks.py`、`src/hooks/plan_completeness_hook.py`、`src/core/loop.py`、`src/memory/extract.py`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选语义：`HookEvaluation {passed, feedback}`、CitationQuality、SourceDiversity、PlanCompleteness；search/fetch 分开计数；当前证据和历史记忆分开。
- 改造要求：TypeScript 重写；确定性 gate 优先；LLM 只给候选；安全/预算 fail closed；质量失败形成 gap。
- 不采用：答案字符数完整性、便宜模型自动持久化可信 memory、hook 异常全部跳过。

### 2.3 Open Deep Research

- 官方仓库：https://github.com/langchain-ai/open_deep_research
- 审阅 commit：`1b7d2e80db9faa586165c60e09096dbbfd483a64`
- 许可证：MIT。
- 重点文件：`src/open_deep_research/configuration.py`、`state.py`、`deep_researcher.py`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选语义：supervisor/researcher state 分开；raw/compressed notes 分开；ConductResearch/ResearchComplete 结构信号；并发、iteration/tool call 上限；overflow 明确回执；搜索后反思。
- 不采用：final report；只有固定次数的预算；broad exception；`is_token_limit_exceeded(...) or True` 错误折叠。

### 2.4 GPT Researcher

- 官方仓库：https://github.com/assafelovic/gpt-researcher
- 审阅 commit：`5d84d2f5553e70a2765a8ff3a0d2672d60437ce8`
- 许可证：Apache-2.0。
- 重点文件：`gpt_researcher/skills/researcher.py`、`skills/deep_research.py`、`deep_agents/BENCHMARK.md`、`SHARE_SUMMARY.md`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选语义：source URL/web/local/hybrid 显式路由；初搜后拆子查询；跨子任务共享 visited URLs；breadth/depth 递减；无成功结果停止；raw search/full scrape/relevance/cited digest 分层；固定预算比较。
- 不采用：报告编辑/写作；固定 depth/breadth 递归；Python 类型与异常边界。
- NOTICE：若未来 copied/adapted，检查并保留 Apache LICENSE、版权、NOTICE 与修改声明。

### 2.5 MindSearch

- 官方仓库：https://github.com/InternLM/MindSearch
- 审阅 commit：`7952c5f8a956fe6a44228a6a7d528a35340e7c87`
- 许可证：Apache-2.0。
- 重点文件：`mindsearch/agent/graph.py`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 仅借鉴：root/subquestion/end 节点、dependency、父问题 context、节点状态与并行。
- 绝不采用：对模型生成内容执行 Python `exec`、固定线程池/全局事件循环、无预算/可信 policy/durable receipt 的执行模式。
- SEL 约束：纯数据 SearchPlanGraphV1 + schema validator + deterministic executor。

### 2.6 STORM

- 官方仓库：https://github.com/stanford-oval/storm
- 审阅 commit：`fb951af7744dab086e34962e9bc6fe878e145f83`
- 许可证：MIT。
- 重点文件：`knowledge_curation.py`、`storm_dataclass.py`、`information_insertion_module.py`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选语义：多 perspective 问题；每维查询/轮数上限；明确 insufficient；URL→Information 聚合；snippet 去重；统一 citation index；按 question/query intent 放入层级结构。
- 改造要求：persona 改为证据覆盖维度；不生成百科结构；层级优先 deterministic，LLM 只给候选。

### 2.7 PaperQA2

- 官方仓库：https://github.com/Future-House/paper-qa
- 审阅 commit：`57e89f7223b0960d5ee5ea048c69e3c47e088572`
- 许可证：Apache-2.0。
- 重点文件：`src/paperqa/core.py`、`docs.py`、`types.py`、`settings.py`、`llms.py`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选语义：Context 绑定 question/source/relevance；summary + relevance 结构化；evidence_k/cutoff/max sources/concurrency 分别配置；按问题分组；MMR 兼顾相关和多样；配置 profiles。
- 不采用：论文专用 Doc/citation 模型；临时交换 session.question 的并发问题；单独信任 LLM relevance score。

### 2.8 Search-R1

- 官方仓库：https://github.com/PeterGriffinJin/Search-R1
- 审阅 commit：`598e61bd1d36895726d28a8d06b3a15bed19f5d3`
- 许可证：Apache-2.0。
- 重点文件：`search_r1/llm_agent/generation.py`、`verl/utils/reward_score/qa_em_format.py`。
- 当前状态：`research-reference-only`。
- 仅研究：search/answer 显式状态；格式、检索命中、答案分别计分；轨迹训练方向。
- M2–M6 不采用：固定 QA/local corpus、exact-match reward、大规模 PPO/GRPO/GPU 训练。

### 2.9 BCAS：Budget-Constrained Agentic Search

- 官方仓库：https://github.com/kmccleary3301/BCAS_RAG
- 审阅 commit：`375797f145c1124a3d9415a5ded78629980344df`
- 许可证：MIT。
- 重点文件：`eval_harness/eval_loops/b_star_05.py`、`cost_tracker.py`、`results.py`、`docs/results-schema.md`、`figure_generation/plot_pareto_budgetB.py`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 直接借鉴方向：search/token 双预算；Planner 预知预算；remaining；previous_searches；ready_to_answer；search traces；tokens in/out、searches used、early stop；YAML experiment grid；accuracy/evidence/cost 联合结果与 Pareto。
- 不复制生产循环：先自增后判断的超限边缘、注释掉的 turn 保护、fallback token 估算。
- 应用阶段：M2 benchmark schema；M3 BudgetLedger；M7 experiment report。

### 2.10 LRAT：Learning to Retrieve from Agent Trajectories

- 官方仓库：https://github.com/Yuqi-Zhou/LRAT
- 审阅 commit：`3384730b24b914ba0c0a101d648d6cb2ad0603d4`
- 许可证：Apache-2.0；仓库另有 `THIRD_PARTY_NOTICES`。
- 重点文件：`docs/trajectory_construction.md`、`docs/training_data_construction.md`、`src/data_builder.py`、`scripts_evaluation/evaluate.py`、`trajectory/bm25/*.json`。
- 当前状态：`reviewed / inspired`；尚未复用。
- 候选语义：稳定 query_id；独立 trajectory JSON；tool_call_counts、retrieved_docids；分步 message/reasoning/tool call/result；轨迹后再转训练样本；Success Rate/Avg Steps/Evidence Recall；positive/negative/satisfied 数据。
- 当前应用：M3 Ledger 留够结构化字段，但不训练；默认不保存原始 reasoning 或其 encrypted ref；显式调试 trace 必须 tenant scoped、短期保留且不得进入公共策略；judge label 只是候选。
- NOTICE：若 copied/adapted，必须保留 Apache 条件和 THIRD_PARTY_NOTICES。

## 3. 论文、评测和无直接代码复用来源

这些来源只用于设计/benchmark，不标为 copied/adapted：

| 来源 | 官方链接 | 用途 | 边界 |
|---|---|---|---|
| SE-Search | https://arxiv.org/abs/2603.03293 | 搜索规划与评估研究参考 | 论文观点不等于生产实现 |
| HotelQuEST | https://aclanthology.org/2026.eacl-industry.16/ | 多步检索、证据质量评测参考 | 不大段复制论文文本 |
| Mind2Web 2 | https://github.com/OSU-NLP-Group/Mind2Web-2 | 冻结环境/任务轨迹评测参考 | 网页操作任务与 SEL 搜索任务需重新建模 |
| BrowseComp | https://openai.com/index/browsecomp/ | 难检索任务与可验证答案参考 | 不把固定答案 benchmark 当开放网页全网 recall |

## 4. 实施前检查表

- [ ] 从官方 URL 重新取得 exact commit；
- [ ] 验证 LICENSE、版权头、NOTICE / THIRD_PARTY_NOTICES；
- [ ] 对照 SEL 当前实现，确认不是重复 durable、URL normalization、provenance、budget；
- [ ] 决定 copied / adapted / inspired 并填写来源行号；
- [ ] 记录本地目标文件、修改和对应测试；
- [ ] 更新 `third-party/NOTICE.md`；
- [ ] 运行 license/SBOM/release contract；
- [ ] 在 PR/Release 说明中区分“借鉴”“已复用”和“已验证”。

## 5. 实际复用记录

当前为空。第一条实际 copied/adapted 记录必须在代码进入仓库的同一个变更中添加。
