# Third-party notice

The AnySearch adapter is an independent implementation of the public protocol documented by the AnySearch project. No AnySearch client source is copied into this package.

- Protocol documentation: https://github.com/anysearch-ai/anysearch-skill/blob/main/scripts/shared/doc_spec.md
- Referenced project license: Apache-2.0
