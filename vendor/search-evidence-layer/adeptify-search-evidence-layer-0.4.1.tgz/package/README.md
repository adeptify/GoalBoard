# Search Evidence Layer

**一句话：这是一个把“明确要查什么”安全地变成可追溯材料的 Node 包；它不替 App 写报告、下产品结论或做 UI。**

npm 包名：`@adeptify/search-evidence-layer`  
当前源码：0.4.1 release source snapshot。对应 GitHub Release 存在后使用该 Release 的 exact tgz；在此之前不要把本快照冒充已经公开可用的正式资产。
要求：Node ≥ 24，pnpm 11.9

---

## 这个仓库是干嘛的？

Adeptify 体系里，多个 App（目前包括 **Relay** 与 **Alchemist / 炼金术**）都可能需要：

1. 按 App 已明确的查询、Feed 和来源边界去公网采集
2. 抽出网页正文  
3. 把材料加密存起来，供 App 做成「证据（Evidence）」再去做分析  

这些能力如果塞进某个具体 App 里，会和 UI、SQLite、Keychain 缠在一起，别的 App 很难复用。

**本仓库就是把「意图边界内执行 + 搜 + 抽 + 安全存储」抽成独立底层包**，App 只负责：

- 决定最终要解决什么业务问题；exact 模式下直接给出查询或 Feed
- 凭证从哪来（BYOK / Keychain）  
- 材料怎么变成产品侧 Evidence、怎么展示、怎么交叉验证  

`0.4.1` 在 `0.4.0` exact Intent 之上补齐生产 storage foundation：App 注入 deadline-aware store 与加密封装端口，包自己管密钥和可信时钟。constrained/adaptive Planner、Strategy Registry 和 Evidence Map 仍未实现。包也 **不生成最终业务答案**。

```
App（如 Relay / Alchemist）
  │  给 exact SearchIntent（查询或 Feed、来源边界、预算）
  │  注入凭证解析、加密端口、SQLite 等
  ▼
@adeptify/search-evidence-layer/intent
  │  Policy/Budget Gate → deterministic exact compiler（无 Planner）
  ▼
@adeptify/search-evidence-layer 现有 Core
  │  调 Provider（AnySearch / RSS / Media / 社交平台）
  │  搜索 / ingest → 合并 → 抽取正文
  │  能力路由 doctor、订阅配额、可选 Browser Host
  │  内容 retain / release、可恢复的 durable 操作
  ▼
返回 materials / receipts / budget 状态；由 App 映射成自己的领域对象
```

---

## 它做什么 / 不做什么

| 做 | 不做 |
|----|------|
| 有界的公网搜索与正文抽取 | 本地语料 / 向量库 / 知识图谱检索 |
| RSS / Atom / JSON Feed 与媒体源摄入 | 绕过付费墙 / 验证码 / 平台反爬 |
| 能力路由与 doctor（rss/web/media/search） | 复制 Agent-Reach / MediaCrawler 源码 |
| 社交平台 Provider（mock-first 契约路径） | UI、报告撰写、LLM 总结 |
| 付费订阅配额 / 审计端口 | 共享账号滥用 |
| Consumer：daemon / CLI / 本地 API / MCP / Skill | 依赖 Client-Core、Tauri、Alchemist、SQLite |
| 加密信封、密钥轮转、内容 retain/release | 内置密码学实现塞进业务 UI |
| 崩溃可恢复的 durable 操作边界 | 云端搜索代理 |

安全底线：

- query、canonical URL、正文等敏感字段默认按信封加密处理  
- checkpoint / 导出路径不应留下可还原的明文 query、密钥、完整正文  
- **核心**对 Client-Core / Tauri / Alchemist / SQLite **零 runtime 依赖**（可选能力按子路径安装；消费方 App 自己接存储/密钥）  
- 社交创作者只存 `creatorHash` + `nicknameMasked`

---

## 给谁用？

| 角色 | 怎么用 |
|------|--------|
| **产品 App**（如 Relay、Alchemist） | 用 exact vendored tgz 安装，只走公开 exports，把 materials 映射成 App 自己的 Evidence |
| **后续第二个消费者** | 同一套包，数据与密钥命名空间按 App 隔离 |
| **本仓维护者** | 在此改 Core / Provider / Host，打 tag、发 tgz；**不要**把 App 业务写进本仓 |

Relay 的产品范围与架构决策只在 Relay `docs/PROJECT.md` 维护；本包只维护 SDK 契约、实现和发布证据。

---

## 安装与导出

本包采用 MIT 许可证。消费方安装 **某一 commit 打出的 exact tgz** 并核对 SHA/PROVENANCE，而不是依赖未锁定的源码目录或随意使用 `latest`。npm 发布仍是维护者单独授权的外部动作。对应 GitHub Release 存在后使用：

```text
https://github.com/adeptify/trick-catalog/releases/download/search-evidence-layer-v0.4.1/adeptify-search-evidence-layer-0.4.1.tgz
```

包对外入口（分层）：

| 导出 | 用途 |
|------|------|
| `@adeptify/search-evidence-layer` | 计划、runtime、能力路由、订阅、实体匿名化、公开类型 |
| `@adeptify/search-evidence-layer/host/node` | Node 生产面：pinned HTTPS、App 注入的受控 Transport/Content Host Port、storage foundation、safe logger |
| `@adeptify/search-evidence-layer/host/browser` | Browser host（mock 契约面；生产可接 Playwright） |
| `@adeptify/search-evidence-layer/feeds` | 默认 Feed 解析器 + 媒体源注册表 |
| `@adeptify/search-evidence-layer/providers/*` | anysearch / rss / media / bilibili / weibo / xhs / douyin / kuaishou / tieba / zhihu / twitter / reddit |
| `@adeptify/search-evidence-layer/consumer` | Daemon / CLI / 本地 HTTP API / MCP / plugin adapters |
| `@adeptify/search-evidence-layer/intent` | exact Intent、来源政策、任务预算、Run Ledger Runtime |
| `@adeptify/search-evidence-layer/testing` | 测试 / 一致性夹具（**不要**在生产业务路径依赖） |

本地开发：

```bash
pnpm install
pnpm check       # typecheck + lint + unit/integration + Node 24 + SBOM
```

打发布包（示例）：

```bash
pnpm release:pack
# 公共发布候选必须来自 clean tree：
pnpm release:pack -- --require-clean
# release/ 同时生成 tgz、SHA-256 和 machine-readable provenance
```

---

## `0.4.1` 新增了什么

- 生产 `/host/node` `createSearchStorageFoundation`：只接受 deadline-aware operation store，不接受测试时钟或密钥注入
- 返回 branded handle：只有 `dataKeyStatus()` 和 `shutdown()`
- `createSearchIntentPersistenceV1` 只接受真实 handle
- RSS/Atom/JSON Feed 只有同时具备稳定 identity（原 id 或独立 `http`/`https` URL）和独立 `http`/`https` URL 的条目才进入材料；坏条目被跳过。至少一个坏条目时稳定返回 `ingest_incomplete`。不能用 feed URL、`#item`/`#entry` 或非 URL id 伪造 identity/URL。缺 title 仍可用 `Untitled`
- 本快照未发布到 npm；对应 GitHub Release 存在后才是可安装资产

## `0.4.0` 已有的 exact 能力

一个代表场景是 Relay-shaped RSS 同步：App 已经登记了 `app:sspai` 和固定 Feed URL。构造 Source 只是数据，不联网；真正执行 exact Intent 时才走同一个现有 RSS Provider。第一次得到 Materials，完全相同的 operation 重放不再联网；同 operation 但 URL、预算或来源政策变了，直接冲突；进程重启能读回 terminal result，Provider 已发出但终态没写下时返回 reconciliation，不猜成功。

`0.4.0` 已有能力：

- additive `SearchIntentExactV1` 执行边界；不修改 V0 SearchPlan 语义
- required / preferred / allowed / forbidden 来源政策与 App 注入的可信 route resolver
- Provider、fetch/extract、model tokens、materials、bytes、并发、deadline、可选 money 的任务预算账本
- exact 正常工作不消费 retry / gap-fill reserve；停止原因、partial 和未执行工作如实返回
- tenant-scoped 加密 Run Ledger、完整 intent fingerprint 幂等、dispatch fence、重启回放和 reconciliation
- Relay-shaped 冻结 RSS 已通过离线 SEL/Client 代表场景；真实 Relay 产品仓尚未迁移

## 0.3.2 已有的基础能力

- 确定性 SearchPlan（含 `ingest`）、URL / 排序核心  
- AnySearch JSON-RPC 适配 + Host 侧 pinned 传输边界  
- RSS / Atom / JSON Feed 解析与 media 源注册表摄入  
- 能力路由 + doctor（rss / web / media / search）  
- Browser mock host + 9 个社交平台 mock-first Provider（创作者匿名化）  
- 付费订阅配额 / 审计（`createSubscriptionManager`）  
- Consumer：daemon / `sel` CLI / `/v1` API / MCP tools / Skill  
- 存储：加密信封、密钥轮转、内容生命周期（retain / release / orphan / App purge）  
- Durable 操作：创建 / 重挂 / 崩溃恢复相关边界  

更细的变更见 [CHANGELOG.md](./CHANGELOG.md)。

**诚实边界：**

- 已验证的真实产品链路是 Relay 的 allowlisted RSS `Source → Sync → Item`，当前仍经旧 direct SDK；本快照只做 Relay-shaped 离线契约，没有修改 Relay 仓
- SearchIntent exact、预算和 Run Ledger 已在本 source snapshot 实现；Strategy Registry、Evidence Map、Adaptive Planner、双 App Beta 都没有实现
- public hosted Gateway 没有实现；测试用 deterministic server 不是生产服务
- 不声称 1.0 稳定 API、不做市场验证结论  
- 发布 Gate 固定在 Node 24 执行；其他 Node 版本通过不替代 Node 24 证据

---

## 仓库结构（简图）

```
src/
  core/          # 计划、内容、操作等领域逻辑
  host/node/     # Node Host 与生产导出
  providers/     # AnySearch 等
  storage/       # 密钥、保留、durable 等
  testing/       # 测试面
  ports/         # 最小端口（AEAD、SecretStore、Blob…）
tests/           # 契约与对抗性回归
```

---

## 许可

[MIT](./LICENSE)。第三方协议说明见 [third-party/NOTICE.md](./third-party/NOTICE.md)，具体包的来源和完整性验证流程见 [PROVENANCE.md](./PROVENANCE.md)。

---

## 相关链接

- 源码目录：https://github.com/adeptify/trick-catalog/tree/main/search-evidence-layer
- Relay 产品 SSOT：https://github.com/adeptify/relay/blob/main/docs/PROJECT.md
- 当前真实消费者：Relay direct SDK；Alchemist constrained/adaptive 代表路径仍在新总体设计阶段
- 新路线先读：[`SEL 专业意图到证据引擎总体设计 V1`](./docs/superpowers/specs/2026-08-13-sel-intent-to-evidence-engine-v1.md)
- 字段与验收细节：[`SEL 专业意图到证据引擎 V1：技术参考`](./docs/superpowers/specs/2026-08-13-sel-intent-to-evidence-engine-v1-technical-reference.md)
