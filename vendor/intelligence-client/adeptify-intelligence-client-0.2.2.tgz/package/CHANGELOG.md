# Changelog

## 0.2.2 - 2026-08-14

- 修正 exact Intent V1 Feed 回执校验：`lane.itemCount` 现在服从本次已校验的 `budget.maxMaterials`，不再错误复用 collect v0 的固定上限 5。
- collect v0 的请求、响应、wire 与 `lane.itemCount <= 5` 语义保持不变；V1 超过本次请求预算、负数或非整数仍会 fail closed 为 `protocol_invalid`。
- 本条目描述 0.2.2 release source snapshot；公开可用性以对应 tag/Release 页面为准。本快照不包含 npm publication、tag/Release 已经完成的声明，或 Relay 用户验收。

## 0.2.1 - 2026-08-14

- Pin the optional `@adeptify/search-evidence-layer` peer to exact `0.4.1`.
- Keep the published Intent V1 request/response wire, `/v1/intents/exact` path, and collect v0 contract unchanged.
- 本条目描述 0.2.1 release source snapshot；公开可用性以对应 tag/Release 页面为准。本快照不包含 npm publication、tag/Release 已经完成的声明，或 Relay 产品迁移。

## 0.2.0 - 2026-08-14

- Keep `intelligence-collect-v0` and `createIntelligenceClient().collect()` unchanged.
- Add the independent `SearchIntentExactV1` request/result contract and `createIntelligenceIntentClientV1()` facade.
- Add an embedded adapter that fixes trusted caller context at construction and delegates execution to the SEL exact Runtime.
- Add `/v1/intents/exact`, strict canonical hosted wire validation, and a deterministic test server/contract kit; the server is not a production Gateway.
- Report multi-dimensional used/remaining/reserve/stop reason truth, fail closed on malformed post-dispatch results, and preserve ambiguous/reattach semantics.
- Public hosted money-capped requests remain disabled until a verifiable production Gateway trust root exists.
- Verify embedded and deterministic hosted semantics against one Relay-shaped RSS execution without adding another RSS implementation.
- 本条目描述 0.2.0 release source snapshot；公开可用性以对应 tag/Release 页面为准。

## 0.1.0 - 2026-08-13

- 定义严格、可版本化的 `intelligence-collect-v0` 请求与响应。
- 提供 embedded Search `0.3.2` 适配，固定路由和预算映射。
- 提供 App-owned hosted auth/call ports，不内置网络或凭据存储。
- 提供确定性 hosted 协议服务器和 21 类 transport-neutral contract。
- 增加对取消、幂等冲突、ambiguous side effect、恶意对象和敏感信息泄漏的回归门禁。
- 以 `intelligence-client-v0.1.0` GitHub Release 发布 exact tgz、SHA-256、provenance 和 SBOM；尚未发布到 npm。
