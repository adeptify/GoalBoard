# Third-party notices

The package has no regular runtime dependencies. Development and testing use
TypeScript, Node.js type declarations, and the optional peer package
`@adeptify/search-evidence-layer`; their licenses are reported in the SBOM.
