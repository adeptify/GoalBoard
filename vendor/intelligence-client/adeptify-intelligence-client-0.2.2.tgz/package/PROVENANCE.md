# Provenance

本包通过 GitHub tag `intelligence-client-v0.1.0` 发布 exact `.tgz`，尚未发布到 npm。下面的 `0.1.0` 内容是已发布历史事实。

`0.2.2` 的公开可用性以对应 tag 与 GitHub Release 页面为准。`0.2.2` 正式资产必须在整个 trick-catalog 工作树 clean、Node 24、pnpm 11.9.0 的条件下生成；它继续精确依赖 Search `0.4.1`，只修正 Client V1 lane 回执上限绑定。随后必须在全新目录验证 collect v0 上限仍为 5、Intent V1 可接受 `lane.itemCount > 5` 但不超过本次 `budget.maxMaterials`，并回下载公开资产复核 SHA。本文件只描述这些门禁，不声称 `0.2.2` tag、Release 或回下载已经发生。

`0.2.1` 的公开可用性以对应 tag 与 GitHub Release 页面为准。`0.2.1` 正式资产必须在整个 trick-catalog 工作树 clean、Node 24、pnpm 11.9.0 的条件下生成，随后精确安装 Search `0.4.1` 与 Client `0.2.1` exact tgz，并把 clean source commit、SHA 和 fresh consumer 结果另行记录，不能覆盖旧 Release 证据。本文件只描述这些门禁，不声称 `0.2.1` tag、Release 或回下载已经发生。

`0.2.0` 的公开可用性同样以对应 tag 与 GitHub Release 页面为准。`0.2.0` 正式资产必须在整个 trick-catalog 工作树 clean、Node 24、pnpm 11.9.0 的条件下生成，随后精确安装 Search `0.4.0` 与 Client `0.2.0` exact tgz。本文件不声称 `0.2.0` tag、Release 或回下载已经发生。

Release 资产必须由干净、已提交的 `intelligence-client/` source snapshot 生成：

```bash
pnpm release:pack -- --require-clean
```

脚本会生成 exact versioned `.tgz`、相邻 `.sha256` 和 machine-readable `.provenance.json`。provenance 记录仓库、package path、source commit、dirty 状态、Node、pnpm、平台、文件字节数、SHA-256 和 npm integrity。GitHub Release 还附带同一 source snapshot 的 CycloneDX SBOM。

复核时必须同时满足：

1. `source.path` 为 `intelligence-client`；
2. `source.dirty` 为 `false`；
3. `.sha256`、provenance 和重新计算的 digest 一致；
4. Node 为 24.x，pnpm 为 11.9.0；
5. 历史 `0.1.0` 复核：全新 consumer 安装 exact Search `0.3.2` tgz 与 Client `0.1.0` tgz 后，root/hosted import 和 embedded fixture collect 通过。

`0.2.2` 发布门禁还须在全新目录安装 exact Search `0.4.1` 与 Client `0.2.2` tgz，验证只安装 Client 时 root/hosted/testing 可加载且 optional Search peer 不会被拉取，双包安装后 collect v0 继续工作，Intent V1 exact query/feed 通过 embedded 和 deterministic hosted 路径且 wire 不变。真实 RSS smoke 走公开 port-backed Host 与 App-owned 有界 HTTPS transport，并额外覆盖大于 5 条候选的 lane 回执；它不等于生产 pinned DNS/TLS Host 或 Relay 网络适配验收。这些门禁不表示远端 Release 已经完成。

仓库维护者在 `main` commit `e1bf02e` 中移除了全部 GitHub Actions workflow，因此本 Release 不包含远端 CI 通过声明。正式门禁是：main 上的 Node 24 全量本地验证、clean-tree provenance、三方 SHA 一致、GitHub Release 资产回下载和 fresh consumer 双包安装。Relay 等消费者仍须锁定 tag、exact tgz 和 digest；真实接入不能由包发布本身替代。
