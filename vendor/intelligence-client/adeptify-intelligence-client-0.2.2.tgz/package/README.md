# @adeptify/intelligence-client

`@adeptify/intelligence-client` 给 App 两条互不偷改的路：已发布的 `collect v0` 保持原样；0.2.2 release source snapshot 继续使用同一套 exact Intent V1 wire，并修正 V1 Feed 回执数量误用 collect v0 上限的问题，再由 Search Evidence Layer 真正采集、记账和恢复。

当前源码是 0.2.2 release source snapshot。对应 GitHub Release 存在后使用该 Release 的 exact tgz；在此之前不要把本快照冒充已经公开可用的正式资产。

## 大白话里的责任分工

| 谁 | 负责什么 | 不负责什么 |
|---|---|---|
| Relay / Alchemist 等 App | 当前用户是谁、允许走哪个 Provider、网络和凭据放在哪里、材料最后变成什么产品对象 | 不拼 SearchPlan，不解析 RSS，不信任远端返回值 |
| Intelligence Client | 固定 collect v0 与 exact Intent V1 请求/响应、预算、错误、取消、幂等和 transport 契约 | 不选业务身份，不保存 token，不自动 fallback 或重试 |
| Search Evidence Layer | 搜索、RSS ingest、正文提取、材料落地、回执与恢复 | 不认识 Relay Item、Idea、Lens、Claim |
| 确定性 hosted server | 在测试里走完整 JSON/auth/status 边界 | 不是生产 Gateway，没有监听端口、TLS、远端 money 信任或共享多租户承诺 |

## 安装

对应 Release 存在后安装 Client `0.2.2` 与 Search `0.4.1`：

```bash
pnpm add \
  https://github.com/adeptify/trick-catalog/releases/download/intelligence-client-v0.2.2/adeptify-intelligence-client-0.2.2.tgz \
  https://github.com/adeptify/trick-catalog/releases/download/search-evidence-layer-v0.4.1/adeptify-search-evidence-layer-0.4.1.tgz
```

只用 root/hosted 时 Search peer 是 optional，不会被入口隐式加载。

## exact Intent V1

当 App 已经明确给了 Feed 或查询时，用独立的 V1 Client；它不会调用 Planner：

```ts
import { createIntelligenceIntentClientV1 } from "@adeptify/intelligence-client";
import { createEmbeddedIntelligenceIntentTransportV1 } from "@adeptify/intelligence-client/embedded";

const client = createIntelligenceIntentClientV1({
  transport: createEmbeddedIntelligenceIntentTransportV1({
    runtime: searchIntentRuntime,
    callerContext: trustedAppSession,
  }),
});

const result = await client.executeExact({
  schema: "search-intent-v1",
  operationId: "relay:source:sspai:sync:42",
  goal: "同步已登记的公开 RSS Source",
  taskProfile: "exact_rss_ingest",
  mode: "exact",
  input: { kind: "feed", url: "https://sspai.com/feed" },
  sourcePolicy: {
    required: [
      { kind: "url", value: "https://sspai.com/feed" },
      { kind: "source_definition", namespace: "app", value: "sspai" },
    ],
    allowed: [{ kind: "domain", value: "sspai.com" }],
  },
  budget: {
    maxProviderCalls: 1,
    maxFetchExtractCalls: 0,
    maxModelInputTokens: 0,
    maxModelOutputTokens: 0,
    maxMaterials: 5,
    maxBytes: 1_000_000,
    maxConcurrency: 1,
    deadlineMs: 15_000,
  },
  partialPolicy: "allow_partial",
  resultProfile: "materials_v1",
});
```

结果会带 outcome、requirementMet、Materials、receipts 和完整预算账本。完全相同的 operation 会重放；同 operation 但 intent 不同会冲突；SEL 已发出网络调用但终态不确定时会要求 reconciliation。缺失字段不会伪造。

public hosted V1 使用 `/v1/intents/exact` 和 App-owned auth/call port。M3 还没有生产 Gateway 或可验证的远端 money 信任根，因此带 `maxMoneyMicros` 的 public hosted 请求会在 auth/call 前 `route_unavailable/change_route`；embedded 只有在 SEL route 给出可信价格时才会执行。

## collect v0（保持兼容）

```ts
import { createIntelligenceClient } from "@adeptify/intelligence-client";

const client = createIntelligenceClient({ transport });
const result = await client.collect({
  schema: "intelligence-collect-v0",
  operationId: "relay:collect:20260813:1",
  depth: "collect_only",
  input: { kind: "query", query: "AI 搜索产品的用户反馈" },
  resultProfile: "materials_v1",
  budget: { maxProviderCalls: 3, maxMaterials: 2, deadlineMs: 10_000 },
  partialPolicy: "allow_partial",
});
```

Client 会先复制、规范化并冻结 request，执行后再校验 response。未知 Transport 异常按“请求可能已经发出”处理成 `ambiguous_transport/reattach`，不会自动重发。

### embedded v0

```ts
import { createIntelligenceClient } from "@adeptify/intelligence-client";
import { createEmbeddedIntelligenceTransportV0 } from "@adeptify/intelligence-client/embedded";

const transport = createEmbeddedIntelligenceTransportV0({
  context: { appId: "relay", principalRef: "user:123", transport: "embedded" },
  runtime: searchRuntime,
  routePolicy: {
    resolve(request) {
      return { providerId: request.input.kind === "feed" ? "rss" : "anysearch" };
    },
  },
});

const client = createIntelligenceClient({ transport });
```

Route Policy 只能返回 Provider ID，不能覆盖 operationId、预算、lane、SearchPlan 或可信身份。M1 embedded 不支持 `tenantId`，因为 Search `0.3.2` 只有 App namespace。

### hosted v0

```ts
import { createIntelligenceClient } from "@adeptify/intelligence-client";
import { createHostedIntelligenceTransportV0 } from "@adeptify/intelligence-client/hosted";

const transport = createHostedIntelligenceTransportV0({
  endpoint: "https://intelligence.example.com/v0/collect",
  auth: {
    async resolveBearer() {
      return { token: await appCredentialStore.read("intelligence") };
    },
  },
  call: {
    async execute(input) {
      return appOwnedHttpPort.execute(input);
    },
  },
});

const client = createIntelligenceClient({ transport });
```

Client 不调用 global `fetch`，也不读环境变量、Keychain 或代理配置。App-owned HTTP Port 必须明确区分 `not_dispatched` 和 `ambiguous`；只有前者才可能安全重试。

### feed v0

feed 仍然走 Search Evidence Layer 的 RSS Provider，没有第二套 RSS：

```ts
await client.collect({
  schema: "intelligence-collect-v0",
  operationId: "relay:feed:sspai:20260813",
  depth: "collect_only",
  input: { kind: "feed", feedUrl: "https://sspai.com/feed" },
  resultProfile: "materials_v1",
  budget: { maxProviderCalls: 1, maxMaterials: 5, deadlineMs: 10_000 },
  partialPolicy: "require_complete",
});
```

## 测试契约

`@adeptify/intelligence-client/testing` 同时保留 collect v0 fixtures，并新增 exact V1 fixtures、contract kit 和 deterministic hosted server。它用于消费者适配和回归，不应进入生产 composition，更不能当生产 Gateway。

```bash
pnpm check
pnpm release:pack -- --require-clean
```

仓库维护者已在 `main` commit `e1bf02e` 中移除全部 GitHub Actions workflow，因此本快照不会声称远端 CI 通过。发布门禁来自 Node 24 本地验证、clean-tree provenance、SHA 交叉核对、对应 Release 存在后的资产回下载和 fresh 双包安装。生产 Gateway、Relay 产品接入、产品实操和用户验收仍未完成。
